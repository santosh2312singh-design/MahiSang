// SETUP REQUIRED for two-phone sync:
// 1) Create a Firebase project at https://console.firebase.google.com/
// 2) Create a Realtime Database and enable Anonymous sign-in in Authentication.
// 3) Paste your web app config below.
// 4) Set Realtime Database rules so only authenticated users can read/write.
//    For a private couple app, a production setup should also restrict access per room.
export const firebaseConfig = {
  apiKey: "PASTE_API_KEY_HERE",
  authDomain: "PASTE_PROJECT_ID_HERE.firebaseapp.com",
  databaseURL: "https://PASTE_DATABASE_NAME_HERE-default-rtdb.firebaseio.com",
  projectId: "PASTE_PROJECT_ID_HERE",
  appId: "PASTE_APP_ID_HERE"
};
