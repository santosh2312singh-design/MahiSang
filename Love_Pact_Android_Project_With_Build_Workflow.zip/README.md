# Love Pact — Android app project

A couples' bad-word counter with three punishment levels:
- Level 1: 1–2 bad words
- Level 2: 3–4 bad words
- Level 3: 5+ bad words (continues at Level 3 as the count rises)

It includes two separate counters, undo, per-person reset, and playful romantic punishments. Counters are manual; the app does not record audio.

## Important: two-phone sync requires setup

The project currently works in local/demo mode. To sync counters between two phones, configure Firebase:

1. Create a Firebase project in the Firebase Console.
2. Add a Web app and copy its configuration into `app/src/main/assets/firebase-config.js`.
3. In Firebase Authentication, enable **Anonymous** sign-in.
4. Create a **Realtime Database**.
5. Set up database security rules. Do not use public read/write rules. For a real private app, restrict access to room members; the simple starter code uses a shared room path and should be hardened before public distribution.
6. Both phones must use the same built APK and enter the same room code.

Firebase docs:
- https://firebase.google.com/docs/web/setup
- https://firebase.google.com/docs/auth/web/anonymous-auth
- https://firebase.google.com/docs/database/web/start

## Build the APK

This is an Android Studio source project, not a precompiled APK. A working Android SDK/Android Studio installation is required to compile it.

1. Open this folder in Android Studio.
2. Let Gradle sync and install any requested Android SDK components.
3. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. Android Studio will show the APK output path.
5. Install the same APK on both phones after configuring Firebase.

## App details

- App name: Love Pact
- Package: `com.lovepact.app`
- Minimum Android version: Android 6.0 (API 23)
- Design: romantic pink, mobile-first
- Default punishments are light, affectionate, and consensual. Change them in `app/src/main/assets/index.html` if you want.

## Notes

This starter project uses Firebase's JavaScript SDK from the WebView. The app requires internet access for Firebase and its SDK. Verify the build and sync flow on your target devices before relying on it.
